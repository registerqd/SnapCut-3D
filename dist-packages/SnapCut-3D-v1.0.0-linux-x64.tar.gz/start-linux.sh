#!/usr/bin/env bash
set -e
cd "$(dirname "$0")"
echo "Starting SnapCut 3D for Linux..."
if command -v node >/dev/null 2>&1; then
    if [ ! -d "node_modules/electron" ]; then
        npm install --omit=dev --silent
    fi
    npx electron . || xdg-open "public/index.html"
else
    xdg-open "public/index.html"
fi
