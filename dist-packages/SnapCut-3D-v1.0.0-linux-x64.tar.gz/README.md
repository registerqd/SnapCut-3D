# SnapCut 3D ⚡

<p align="center">
  <img src="https://img.shields.io/badge/SnapCut-3D_Desktop-00e5a3?style=for-the-badge&logo=electron&logoColor=white" alt="SnapCut 3D" />
</p>

<p align="center">
  <strong>专治 3D 打印大件塞不进机器 · 免学复杂建模 · 30秒生成无胶水磁吸与防呆榫卯分件</strong><br>
  <em>Cross-Platform Desktop Application (Windows / macOS / Linux) & Web</em>
</p>

<p align="center">
  <a href="#-为什么需要-snapcut-3d"><img src="https://img.shields.io/badge/适用场景-大件切分%20%7C%20磁吸组装%20%7C%20榫卯连接-blue?style=flat-square" alt="Use Cases"></a>
  <a href="#-打印机与连接件兼容生态"><img src="https://img.shields.io/badge/兼容生态-拓竹_Bambu%20%7C%20OrcaSlicer%20%7C%20创想-00AE42?style=flat-square" alt="Compatibility"></a>
  <a href="LICENSE"><img src="https://img.shields.io/badge/开源协议-MIT-green?style=flat-square" alt="License"></a>
  <img src="https://img.shields.io/badge/Electron-33%2B-47848F?style=flat-square&logo=electron&logoColor=white" alt="Electron Version">
  <img src="https://img.shields.io/badge/Node.js-20%2B-brightgreen?style=flat-square" alt="Node Version">
  <img src="https://img.shields.io/badge/架构-纯本地几何运算%20%7C%20零依赖GPU-orange?style=flat-square" alt="Architecture">
</p>

---

## 💡 为什么需要 SnapCut 3D？

随着消费级 3D 打印机（如拓竹 A1 mini、P1S/X1C、创想 Ender 系列等）的大规模普及，越来越多玩家与创客想要打印**大型手办雕像、头盔面具、Cosplay 长刀长剑道具、收纳盒与电子外壳**。

但绝大多数人都被卡在同一个致命物理瓶颈上：

1. **成型体积受限**：入门爆款拓竹 A1 mini 仅有 **180×180×180mm**，主流主力机型也仅为 **256mm** 立方体。尺寸一旦超过 200~300mm，**100% 无法直接打印，必须切开**。
2. **切片软件自带切割太弱**：
   - 只能傻瓜式平面一切为二，无法打市售标准强磁沉头孔；
   - 缺乏防呆机制，切开后两面完全对称，打印出来极易**装反、拼歪、旋转扭曲**；
   - 复杂曲面布尔运算极易产生破面、非流形边和微小悬空。
3. **专业 3D 建模软件门槛劝退**：
   - Blender、Fusion 360、ZBrush 的布尔运算与对齐装配门槛极高，新手为了切一个零件要学数周软件操作。
4. **圈内当下的最大流量密码：【磁吸 / 榫卯快拆组装】**：
   - 玩过 3D 打印的都知道：**免胶水、咔哒一声磁吸吸合、模块化快拆**，在 MakerWorld、Printables、B 站和小红书上拥有极强的自传播力与装配爽感！

**SnapCut 3D 桌面端应用就是为此而生的专属利器**：拖入模型 → 选择打印机与磁铁/榫卯规格 → 30秒生成带公差沉头孔与防呆榫卯的分件 STL，并附带五金采购与装配指南 BOM。

---

## 🥊 方案全方位对比

| 对比维度 | 切片软件内置切割 (Bambu/Orca) | 专业建模软件 (Blender/CAD) | 商业软件 (鲁班 LuBan 等) | **SnapCut 3D Desktop (本项目)** |
| :--- | :--- | :--- | :--- | :--- |
| **客户端形态** | 嵌入在切片软件中 | 庞大重型专业软件 | 独立商业软件（收费臃肿） | **原生轻量桌面端 (Electron) + Web 双模** |
| **上手门槛** | 极低（但功能简陋） | 极高（需专业 3D 基础） | 中等（UI 繁琐陈旧） | **零门槛（拖入即切）** |
| **市售磁铁沉孔** | ❌ 不支持（需手动挖孔） | ⚠️ 需手动绘制圆柱布尔差集 | ⚠️ 配置复杂且规格不全 | **✅ 一键匹配市售主流强磁** |
| **防呆设计** | ❌ 仅普通圆销易装反 | ⚠️ 需手动设计偏心销 | ⚠️ 仅传统木工榫 | **✅ D 型截面杜绝旋转反装** |
| **打印公差补偿** | ❌ 需反复手工微调偏移 | ⚠️ 需手动计算膨胀/缩进 | ⚠️ 算法黑盒常导致卡死 | **✅ 内置 0.15~0.25mm 补偿** |
| **计算性能** | 本地切片，易破面报错 | 依赖显卡与复杂网格求交 | 较慢，商业授权绑定 | **✅ 纯本地百毫秒级几何切削** |
| **一键平放热床** | 需手动多步旋转与找面 | 需手动贴合平面 | 自动（但常摆偏） | **✅ 一键以切面贴合打印床** |
| **交付 BOM 清单** | ❌ 无 | ❌ 无 | ❌ 无 | **✅ 自动导出采购与装配 BOM** |

---

## ✨ 核心特性

### 1. 🖥️ 原生跨平台桌面体验 (Electron)
- 沉浸式暗黑工业设计，窗口大小自由缩放，全离线可用；
- 深度集成系统原生文件选择对话框与原生保存路径对话框，告别网页下载目录混杂困扰；
- 支持同时作为轻量 Web 服务运行，双模架构随意切换。

### 2. 🎯 主流 3D 打印机成型仓实时比对
- 内置 **拓竹 A1 mini (180³)**、**P1S / X1C / A1 (256³)**、**创想 Ender-3 (220×220×250)**、**纵维立方 Kobra 系列** 等机型成型空间立方体。
- 自动识别长、宽、高各轴向是否超限，直观标红预警，并智能推荐下刀轴向。

### 3. ⚡ 毫秒级纯本地几何切削与截面重建
- 纯 JavaScript 解析几何算法，百毫秒内完成相交线段提取与闭合环（Polygon Loops）拼接。
- 基于轻量高效的 **Earcut 算法** 实现带孔洞平面的高质量约束 Delaunay 三角剖分，**不依赖任何重型第三方库或云端 GPU**，杜绝非流形破面。

### 4. 🧲 市售标准强磁沉头孔自动生成
- 预设市售最容易采购的钕铁硼强磁尺寸：
  - **φ6 × 3 mm**（圈内首选·手办道具黄金尺寸，吸力 ~0.8kg）
  - **φ5 × 2 mm**（超薄小件、轻量零件、关节活动件）
  - **φ8 × 2 mm**（扁平大吸力、重型底座首选）
  - **φ10 × 3 mm**（大宝剑/长刀切件、承重件首选）
- 自动提供 **单孔居中**、**双孔对称**、**四孔矩阵** 布局。
- **自带挤出公差补偿（Clearance）**：默认预留 +0.2mm 内径余量与 +0.3mm 胶水沉头深度，打印完毕后磁铁直接压入，免去打磨烦恼。

### 5. 🪵 D 型截面防呆榫卯定位
- 采用创新的 **D 型截面（单侧切平）** 定位榫：
  - Part A 自动生成预留公差的 Socket 凹槽；
  - Part B 自动生成精准匹配的 Pin 凸台；
  - 彻底从几何根源上消除旋转松动与 180° 反向误装。
- 凸台顶部集成 **1mm 45° 导向倒角**，拼合时自动滑入自锁。

### 6. 💥 3D 爆炸分离检视 & 一键平放热床
- 切割完成后，零件自动沿切面法向量双向爆开分离，直观透视内部孔槽深度与形状。
- **一键平放热床**：自动计算切面法向与热床的旋转四元数，将切面作为底面平铺在打印床上，**免去打孔悬空支撑**，且获得最大的第一层附着面积。

### 7. 📦 全套 STL 资产导出与 BOM 采购指南
- 支持分别独立保存 `PartA_切分件.stl` 和 `PartB_切分件.stl`（标准紧凑二进制 STL 格式）。
- 支持一键导出 **ZIP 完整交付包**：内含零件模型，以及由系统自动生成的《装配指南与五金采购清单_BOM.txt》，包含所需磁铁尺寸数量、极性标记提醒与推荐切片参数。

---

## 🔩 常用连接件规格速查表

| 连接件型号 | 标称规格 | 推荐公差 | 预估吸力 / 强度 | 推荐适用场景 |
| :--- | :--- | :--- | :--- | :--- |
| **φ6 × 3 mm 强磁** | 直径 6mm, 厚 3mm | +0.20 mm | ~0.8 kg | **手办头部、手臂快拆、剑柄、收纳盖板（最推荐）** |
| **φ5 × 2 mm 强磁** | 直径 5mm, 厚 2mm | +0.15 mm | ~0.4 kg | 纤细小件、薄壁外壳、轻量玩偶部件 |
| **φ8 × 2 mm 强磁** | 直径 8mm, 厚 2mm | +0.20 mm | ~1.2 kg | 桌面平整底座、展示架拼接、重型机械件 |
| **φ10 × 3 mm 强磁** | 直径 10mm, 厚 3mm | +0.25 mm | >2.0 kg | Cosplay 巨剑、大号战锤、盾牌大件 |
| **D 型防呆榫卯** | 直径 8mm, 长 12mm | +0.20 mm | 高抗扭刚度 | **纯打印一体件、无需五金配件、需要极高定位精度** |
| **经典圆柱定位销** | 直径 8mm, 长 12mm | +0.20 mm | 中等刚度 | 轴对称圆柱形零件（如水管、手柄筒体） |

---

## 🚀 快速上手与运行

### 方式一：运行桌面客户端 (推荐)

```bash
# 1. 克隆代码
git clone https://github.com/registerqd/SnapCut-3D.git
cd SnapCut-3D

# 2. 安装依赖
npm install

# 3. 启动桌面客户端
npm start
```

### 方式二：打包为独立安装包 (Windows / macOS / Linux)

```bash
# 构建 Windows 安装程序 (.exe / nsis)
npm run dist:win

# 构建 macOS 安装镜像 (.dmg)
npm run dist:mac

# 构建 Linux 便携程序 (.AppImage)
npm run dist:linux
```
生成的安装包将存放在 `dist/` 目录下。

### 方式三：以轻量 Web 模式运行

```bash
npm run web
# 访问 http://localhost:3008
```

---

## 📂 项目结构

```text
SnapCut-3D/
├── main.cjs               # Electron 主进程 (窗口生命周期、原生 IPC 通信、原生文件对话框)
├── preload.cjs            # Electron 安全上下文预加载通道 (contextBridge)
├── server.js              # Web 模式内置服务 (Express API 与 ZIP 归档)
├── package.json           # 项目配置、依赖与 electron-builder 构建脚本
├── README.md              # 完整项目指南
├── LICENSE                # MIT 开源授权协议
├── .gitignore             # Git 忽略配置
├── assets/                # 应用图标与静态资源
│   └── icon.png           # 桌面客户端高分辨率应用图标
├── samples/               # 内置 3 款典型超限测试 STL 模型
│   ├── cyber-blade-hilt.stl     # 赛博光剑手柄 (长 290mm，长轴超限)
│   ├── mecha-helmet-mask.stl    # 机甲面具头盔 (高 230mm，立高超限)
│   └── modular-storage-bin.stl  # 模块化收纳盒 (长 270mm，横向超限)
└── public/                # 渲染进程前端应用
    ├── index.html         # 工作台主界面
    ├── css/
    │   └── style.css      # 现代工业暗黑风格 UI 样式
    ├── js/
    │   ├── app.js         # 前端主控制器 (Electron 原生对话框检测与调度)
    │   ├── viewer.js      # Three.js 3D 渲染器、切刀变换、成型仓与爆炸视图
    │   ├── slicer.js      # 解析几何切削算法与 Earcut 闭合拓扑引擎
    │   ├── stl-utils.js   # 二进制与 ASCII STL 高性能解析/导出
    │   └── presets.js     # 打印机、磁铁、榫卯参数数据库
    ├── lib/               # 本地离线依赖库 (Three.js, Earcut, OrbitControls)
    └── samples/           # 前端可直接读取的静态示例模型
```

---

## 🛠️ 创客装配与切片打印指南

1. **磁极防反装测试（非常关键！）**：
   - 压入磁铁之前，**务必先用两颗磁铁互相吸附测试**；
   - 用细油性记号笔在互相吸合的接触面上各点一个标记点；
   - 确保安装时：A 件露出标记点，B 件朝内压入标记点（保证两件靠近时能**自动吸合**，而不是相斥！）。
2. **切片软件打印参数推荐**：
   - **摆放方向**：使用工具界面的「🛏️ 一键平放热床」，将切削截面作为底面贴紧热床，免去内部支撑并获得极佳粘结力；
   - **外壁圈数（Wall Loops）**：设置为 **3 ~ 4 圈**（>= 1.2mm），保证磁铁孔壁具有足够的挤压强度，防止压入时崩裂；
   - **填充率（Infill）**：推荐 **15% ~ 25% 陀螺线（Gyroid）** 或自适应立方体填充。
3. **磁铁固定**：
   - 工具已预留 +0.2mm 适度公差；如果打印机轻微欠挤出导致偏松，在孔底点涂一小滴 **401 瞬间强力胶** 即可永久牢固固定。

---

## 🗺️ 路线图 (Roadmap)

- [x] Electron 跨平台桌面客户端支持 (Windows / macOS / Linux)
- [x] 拓竹全系列与主流机型打印床体积可视化
- [x] 解析几何多边形相交与拓扑闭合
- [x] 市售标准强磁沉孔（带挤出公差自动补偿）
- [x] D 型防呆榫卯公母槽自动生成
- [x] 3D 爆炸分离视图与切面一键平放热床
- [x] 打包导出 ZIP 与 BOM 采购清单
- [ ] 支持多平面连续切分（一刀切 4 件或 8 件）
- [ ] 支持异形曲线拼合切刀（针对表面细节防穿孔）
- [ ] 导出拓竹 Bambu Studio / OrcaSlicer 预设工程文件 (`.3mf`)

---

## 📄 开源许可证

本项目基于 [MIT License](LICENSE) 开源。欢迎广大创客与开发者提交 Issue 和 PR 共同完善！
